package com.restaurant.entity;

public class Cart {
}
