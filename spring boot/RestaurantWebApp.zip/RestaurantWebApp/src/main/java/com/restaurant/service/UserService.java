package com.restaurant.service;




import com.restaurant.entity.RoleType;
import com.restaurant.entity.User;
import com.restaurant.exception.RestaurantException;

import com.restaurant.repository.RoleRepository;
import com.restaurant.repository.UserRepository;
import com.restaurant.requestwrapper.UserLoginRequestWrapper;
import com.restaurant.requestwrapper.UserRequestWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class UserService  implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;


    public void createUser(UserRequestWrapper request) throws RestaurantException
    {
        Optional<User> user= userRepository.findByEmailIgnoreCase(request.getEmail());
        User newUser= new User();
        RoleType role= roleRepository.findByRole(request.getRole());

        if (user.isEmpty())
        {
            newUser.setFullName(request.getFullName());
            newUser.setEmail(request.getEmail());
            newUser.setPassword(passwordEncoder.encode(request.getPassword()));
            if(role!=null)
            {
                newUser.setRole(role);
            }
            else {
                throw new RestaurantException("Role not exist",400);
            }
            userRepository.save(newUser);
        }
        else
        {
            throw new RestaurantException("User already exist",400);
        }

    }

    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {

        Optional<User> opt = userRepository.findByEmailIgnoreCase(email);

        org.springframework.security.core.userdetails.User springUser = null;

        if (opt.isEmpty()) {
            throw new UsernameNotFoundException("User with email: " + email + " not found");
        }
        User user = opt.get();
        List<RoleType> roles = roleRepository.findAll();
        Set<GrantedAuthority> ga = new HashSet<>();
        for (RoleType role : roles) {
            ga.add(new SimpleGrantedAuthority(role.getRole()));
        }

        springUser = new org.springframework.security.core.userdetails.User(
                email,
                passwordEncoder.encode(user.getPassword())
                ,
                ga);
        return springUser;

    }


    public boolean login(UserLoginRequestWrapper userLoginRequestWrapper) throws RestaurantException
    {
        Optional<User> user= userRepository.findByEmailIgnoreCase(userLoginRequestWrapper.getEmail());


        if (user.isPresent())
        {
           if (user.get().getPassword().equals(userLoginRequestWrapper.getPassword())) {
               return true;
           }
        }

        return false;
    }

}
