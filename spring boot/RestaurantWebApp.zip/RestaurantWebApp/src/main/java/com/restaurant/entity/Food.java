package com.restaurant.entity;


import jakarta.persistence.*;

@Entity
@Table(name="food_table")
public class Food {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "food_name")
    private String name;
    @Column(name = "food_price")
    private Double price;
    @Column(name = "food_rating")
    private int rating;

}
